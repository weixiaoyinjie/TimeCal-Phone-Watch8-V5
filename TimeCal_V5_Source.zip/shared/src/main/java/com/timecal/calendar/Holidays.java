package com.timecal.calendar;
import android.icu.util.ChineseCalendar;
import android.icu.util.Calendar;
import android.icu.util.TimeZone;
import java.time.*;
import java.util.*;
final class Holidays {
    static final String[] MONTH={"正月","二月","三月","四月","五月","六月","七月","八月","九月","十月","冬月","腊月"};
    static final String[] DAY={"","初一","初二","初三","初四","初五","初六","初七","初八","初九","初十","十一","十二","十三","十四","十五","十六","十七","十八","十九","二十","廿一","廿二","廿三","廿四","廿五","廿六","廿七","廿八","廿九","三十"};
    static ChineseCalendar lunar(LocalDate d){ ChineseCalendar c=new ChineseCalendar(); c.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai")); c.setTimeInMillis(d.atTime(12,0).atZone(ZoneId.of("Asia/Shanghai")).toInstant().toEpochMilli()); return c; }
    static String lunarText(LocalDate d, boolean full){ ChineseCalendar c=lunar(d); int n=c.get(Calendar.DAY_OF_MONTH); String m=(c.get(Calendar.IS_LEAP_MONTH)==1?"闰":"")+MONTH[c.get(Calendar.MONTH)]; return full?m+DAY[n]:n==1?(c.get(Calendar.IS_LEAP_MONTH)==1?"闰":"")+(c.get(Calendar.MONTH)+1)+"月":DAY[n]; }
    static boolean range(LocalDate d,int m,int a,int b){return d.getMonthValue()==m&&d.getDayOfMonth()>=a&&d.getDayOfMonth()<=b;}
    static String china(LocalDate d){int m=d.getMonthValue(), n=d.getDayOfMonth(), y=d.getYear(); ChineseCalendar c=lunar(d); int lm=c.get(Calendar.MONTH)+1, ld=c.get(Calendar.DAY_OF_MONTH); if(c.get(Calendar.IS_LEAP_MONTH)==0){if(lm==1&&ld==1)return "春节";if(lm==1&&ld==15)return "元宵节";if(lm==5&&ld==5)return "端午节";if(lm==7&&ld==7)return "七夕";if(lm==8&&ld==15)return "中秋节";if(lm==9&&ld==9)return "重阳节";if(lm==12&&ld==8)return "腊八节";ChineseCalendar next=lunar(d.plusDays(1));if(lm==12&&next.get(Calendar.MONTH)==0&&next.get(Calendar.DAY_OF_MONTH)==1)return "除夕";}
        if(m==1&&n==1)return "元旦"; if(m==5&&n==1)return "劳动节";if(m==10&&n==1)return "国庆节";
        String online=HolidayUpdates.cached("CN",d);if(online!=null)return online;
        if(y==2026){if(range(d,1,1,3))return "元旦假期";if(range(d,2,15,23))return "春节假期";if(range(d,4,4,6))return n==5?"清明节":"清明假期";if(range(d,5,1,5))return "劳动节假期";if(range(d,6,19,21))return "端午假期";if(range(d,9,25,27))return "中秋假期";if(range(d,10,1,7))return "国庆假期";}
        if(y==2027){if(range(d,1,1,3))return "元旦假期";if(range(d,2,5,13))return "春节假期";if(range(d,4,3,5))return n==5?"清明节":"清明假期";if(range(d,5,1,5))return "劳动节假期";if(range(d,10,1,7))return "国庆假期";}
        return "";
    }
    static LocalDate easter(int y){int a=y%19,b=y/100,c=y%100,d=b/4,e=b%4,f=(b+8)/25,g=(b-f+1)/3,h=(19*a+b-d-g+15)%30,i=c/4,k=c%4,l=(32+2*e+2*i-h-k)%7,m=(a+11*h+22*l)/451,v=h+l-7*m+114;return LocalDate.of(y,v/31,v%31+1);}
    static LocalDate moved(LocalDate d){switch(d.getDayOfWeek()){case TUESDAY:return d.minusDays(1);case WEDNESDAY:return d.minusDays(2);case THURSDAY:return d.plusDays(4);case FRIDAY:return d.plusDays(3);default:return d;}}
    static String argentina(LocalDate d){String online=HolidayUpdates.cached("AR",d);if(online!=null){if(online.isEmpty()&&d.equals(easter(d.getYear()).minusDays(3)))return "圣周四·非工作日";return online;}int y=d.getYear();String md=d.toString().substring(5);List<String> names=new ArrayList<>();switch(md){case "01-01":names.add("元旦");break;case "03-24":names.add("真相与正义纪念日");break;case "04-02":names.add("马岛纪念日");break;case "05-01":names.add("劳动节");break;case "05-25":names.add("五月革命纪念日");break;case "06-20":names.add("国旗日");break;case "07-09":names.add("独立日");break;case "12-08":names.add("圣母无染原罪节");break;case "12-25":names.add("圣诞节");break;}
        LocalDate e=easter(y);if(d.equals(e.minusDays(48))||d.equals(e.minusDays(47)))names.add("狂欢节");if(d.equals(e.minusDays(2)))names.add("耶稣受难日");if(d.equals(e.minusDays(3)))names.add("圣周四·非工作日");
        String[] ds={"06-17","08-17","10-12","11-20"};String[] ns={"格梅斯纪念日","圣马丁纪念日","文化多样性日","国家主权日"};for(int j=0;j<ds.length;j++){LocalDate base=LocalDate.parse(y+"-"+ds[j]);if(d.equals(moved(base)))names.add(ns[j]);}
        if(y==2026){if(md.equals("03-23")||md.equals("07-10")||md.equals("12-07"))names.add("旅游非工作日");if(md.equals("11-09"))names.add("全国特别假日");}
        return String.join(" · ",names);
    }
}
